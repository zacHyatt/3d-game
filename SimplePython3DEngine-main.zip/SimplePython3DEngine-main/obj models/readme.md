javix9 obj files:
https://github.com/OneLoneCoder/videos/search?q=obj

Cartoon Baby Crocodile Low Poly 3D Model:
https://www.cadnav.com/3d-models/model-52983.html

Abandoned Cottage House
https://free3d.com/3d-model/abandoned-cottage-house-825251.html

AH-64 Apache Helicopter 3D Model
https://www.cadnav.com/3d-models/model-52775.html
